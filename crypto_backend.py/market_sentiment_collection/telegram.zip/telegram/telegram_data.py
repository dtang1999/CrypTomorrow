from telethon import TelegramClient
from datetime import datetime, timezone
from dotenv import load_dotenv
import os
import asyncio
from db_utils import insert_matched_post

load_dotenv()
# 用你自己申请到的 ID 和 HASH
api_id = os.getenv("TELEGRAM_API_ID")
api_hash = os.getenv("TELEGRAM_API_HASH")
phone_number = os.getenv("PHONE")


def load_keywords_from_file(file_name):
    """
    file_name: 只传简单文件名，比如 'btc_first.txt'
    自动拼接到 'keywords/' 文件夹里
    """
    base_path = os.path.dirname(__file__)  # 当前这个.py脚本所在目录
    keywords_dir = os.path.join(base_path, "keywords")  # keywords目录
    file_path = os.path.join(keywords_dir, file_name)  # 拼出完整路径

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"关键词文件找不到！路径检查一下：{file_path}")

    keywords = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            kw = line.strip()
            if kw:
                keywords.append(kw.lower())
    return keywords


def extract_matched_keywords(text, keywords):
    """
    提取出文本中出现过的关键词，大小写不敏感。
    """
    if not text:
        return []
    text = text.lower()
    return [kw for kw in keywords if kw in text]


def parse_datetime_custom(date_str):
    """
    把 MM/DD/YYYY HH:MM 格式的字符串，转换成 UTC datetime对象
    """
    dt = datetime.strptime(date_str, "%m/%d/%Y %H:%M")
    # 加上 UTC时区信息
    return dt.replace(tzinfo=timezone.utc)


async def main(channel_username=None, limit=None, start_time=None):
    client = TelegramClient("session_name", api_id, api_hash)
    await client.start(phone=phone_number)

    print("✅ 开始监听Telegram频道/群组消息...")

    messages = await client.get_messages(
        channel_username,
        limit=limit,
        offset_date=start_time,
        reverse=True,  # 重点！！！往未来抓
    )

    total_messages = len(messages)
    matched_messages = 0  # 命中关键词的数量
    KEYWORDS = load_keywords_from_file("btc_first.txt")

    for message in messages:
        if not message.text:
            continue

        matched_keywords = extract_matched_keywords(message.text, KEYWORDS)

        if matched_keywords:
            matched_messages += 1
            print("🎯 命中关键词！")
            print(f"关键词: {matched_keywords}")
            print(f"内容: {message.text[:200]}")
            print(f"发送时间: {message.date.isoformat()}")
            print("=" * 40)

            insert_matched_post(
                message_id=message.id,
                text=message.text,
                keywords=matched_keywords,
                timestamp=message.date,
                channel=channel_username,
            )

    print(f"\n✅ 报告：")
    print(f"- 抓取总消息数：{total_messages}")
    print(f"- 命中关键词消息数：{matched_messages}")


# 新增：可供外部调用的封装函数
async def fetch_telegram_texts(
    channel_username, limit, start_time, keyword_file="btc_first.txt"
):
    client = TelegramClient("session_name", api_id, api_hash)
    await client.start(phone=phone_number)

    messages = await client.get_messages(
        channel_username,
        limit=limit,
        offset_date=start_time,
        reverse=True,
    )

    KEYWORDS = load_keywords_from_file(keyword_file)
    results = []

    for message in messages:
        if not message.text:
            continue

        matched_keywords = extract_matched_keywords(message.text, KEYWORDS)
        if matched_keywords:
            results.append(
                {
                    "text": message.text,
                    "keywords": matched_keywords,
                    "timestamp": message.date.isoformat(),
                    "channel": channel_username,
                }
            )

    return results


if __name__ == "__main__":

    channel_username = "binancekillers"
    limit = 50  # 想抓多少条（比如抓300条）
    start_time_str = "04/25/2025 00:00"

    # 转成datetime对象
    start_time = parse_datetime_custom(start_time_str)

    asyncio.run(
        main(
            channel_username=channel_username,
            limit=limit,
            start_time=start_time,
        )
    )
