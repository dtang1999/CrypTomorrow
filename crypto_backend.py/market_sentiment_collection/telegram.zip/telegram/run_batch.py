import asyncio
import json

from telegram_data import fetch_and_store_channel_data
from telegram_data import parse_datetime_custom


def load_channel_config():
    with open("config/channels.txt", "r") as f:
        channels = [line.strip() for line in f if line.strip()]
    with open("config/keyword_map.json", "r") as f:
        keyword_map = json.load(f)
    return channels, keyword_map


async def run_batch():
    channels, keyword_map = load_channel_config()
    start_time = parse_datetime_custom("04/25/2025 00:00")

    for channel in channels:
        keyword_file = keyword_map.get(channel, "default.txt")
        print(f"Processing channel: {channel} with keywords: {keyword_file}")
        await fetch_and_store_channel_data(
            channel_username=channel,
            limit=50,
            start_time=start_time,
            keyword_file=keyword_file,
        )


if __name__ == "__main__":
    asyncio.run(run_batch())
