import psycopg2
import os


from text_utils import summarize_text


def insert_matched_post(message_id, text, keywords, timestamp, channel):
    summary = summarize_text(text)

    conn = psycopg2.connect(
        host=os.getenv("PG_HOST"),
        port=os.getenv("PG_PORT"),
        user=os.getenv("PG_USER"),
        password=os.getenv("PG_PASSWORD"),
        dbname=os.getenv("PG_DATABASE"),
    )
    cur = conn.cursor()

    # 建表 & 插入（含 summary 字段）
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS sentiment_db (
            id SERIAL PRIMARY KEY,
            message_id BIGINT NOT NULL,
            text TEXT NOT NULL,
            summary TEXT,
            keywords TEXT[] NOT NULL,
            timestamp TIMESTAMPTZ NOT NULL,
            channel TEXT NOT NULL,
            classified BOOLEAN DEFAULT FALSE,
            label VARCHAR(10),
            score FLOAT,
            UNIQUE (message_id, channel)
        );
    """
    )

    cur.execute(
        """
        INSERT INTO sentiment_db (message_id, text, summary, keywords, timestamp, channel)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (message_id, channel) DO NOTHING;
    """,
        (message_id, text, summary, keywords, timestamp, channel),
    )

    conn.commit()
    cur.close()
    conn.close()
